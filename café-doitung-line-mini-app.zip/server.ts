import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';

interface OrderItem {
  itemId?: string;
  itemName: string;
  temp?: 'Hot' | 'Iced' | 'Frappe' | string;
  sweetness?: '0%' | '25%' | '50%' | '100%' | string;
  milk?: 'Standard Dairy' | 'Oat Milk' | 'Soy Milk' | 'Almond Milk' | string;
  price: number;
  quantity: number;
  ecoCup?: boolean;
  notes?: string;
}

interface Order {
  orderId: string;
  lineUserId?: string;
  branch: string;
  items: OrderItem[];
  totalAmount: number;
  pickupTime: string;
  customerName: string;
  customerPhone: string;
  note?: string;
  createdAt: string;
  status: 'received' | 'preparing' | 'ready_for_pickup' | 'completed';
  estimatedMinutes?: number;
}

const orders: Order[] = [
  // Sample initial seed order for demonstration
  {
    orderId: 'DT-1001',
    branch: 'DoiTung Flagship Store (Chiang Rai)',
    items: [
      {
        itemName: 'DoiTung Signature Drip Coffee',
        temp: 'Hot',
        sweetness: '50%',
        milk: 'Standard Dairy',
        price: 105, // 110 - 5 THB eco discount
        quantity: 1,
        ecoCup: true,
        notes: 'Single origin Chiang Rai beans'
      },
      {
        itemName: 'Iced Macadamia Latte',
        temp: 'Iced',
        sweetness: '25%',
        milk: 'Oat Milk',
        price: 150, // 130 + 5 (Iced) + 15 (Oat)
        quantity: 1,
        ecoCup: false
      }
    ],
    totalAmount: 255,
    pickupTime: 'ASAP (10-15 mins)',
    customerName: 'Narin S.',
    customerPhone: '0812345678',
    note: 'Extra hot on the drip, please.',
    createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    status: 'preparing',
    estimatedMinutes: 12
  }
];

let orderCounter = 1002;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // CORS Middleware for seamless local testing
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PATCH, OPTIONS');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // REST API Endpoints

  // GET /api/orders - List all orders
  app.get('/api/orders', (req, res) => {
    res.json({
      success: true,
      data: orders
    });
  });

  // GET /api/orders/:orderId - Retrieve specific order details
  app.get('/api/orders/:orderId', (req, res) => {
    const { orderId } = req.params;
    const order = orders.find((o) => o.orderId.toLowerCase() === orderId.toLowerCase());
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }
    res.json({ success: true, data: order });
  });

  // POST /api/orders - Create a new pre-order
  app.post('/api/orders', (req, res) => {
    try {
      const {
        lineUserId,
        branch,
        items,
        totalAmount,
        pickupTime,
        customerName,
        customerPhone,
        note
      } = req.body;

      // Input Validation
      if (!customerName || !customerPhone) {
        return res.status(400).json({
          success: false,
          message: 'Customer name and mobile phone number are required.'
        });
      }

      if (!items || !Array.isArray(items) || items.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Your cart is empty. Please select at least one item.'
        });
      }

      // Generate unique Order ID
      const newOrderId = `DT-${orderCounter++}`;

      // Calculate estimate time based on queue length
      const activeQueue = orders.filter(
        (o) => o.status === 'received' || o.status === 'preparing'
      ).length;
      const baseEstimate = pickupTime?.includes('30') ? 30 : pickupTime?.includes('1 hour') ? 60 : 15;
      const estimatedMinutes = baseEstimate + activeQueue * 2;

      const newOrder: Order = {
        orderId: newOrderId,
        lineUserId: lineUserId ? String(lineUserId) : undefined,
        branch: branch || 'DoiTung Flagship Store',
        items: items.map((item: any) => ({
          itemName: item.itemName || 'Specialty Coffee',
          temp: item.temp || 'Hot',
          sweetness: item.sweetness || '50%',
          milk: item.milk || 'Standard Dairy',
          price: Number(item.price) || 0,
          quantity: Number(item.quantity) || 1,
          ecoCup: Boolean(item.ecoCup),
          notes: item.notes || ''
        })),
        totalAmount: Number(totalAmount) || 0,
        pickupTime: pickupTime || 'ASAP (10-15 mins)',
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        note: note ? note.trim() : '',
        createdAt: new Date().toISOString(),
        status: 'received',
        estimatedMinutes
      };

      orders.unshift(newOrder);

      return res.status(201).json({
        success: true,
        message: 'Order created successfully',
        data: newOrder
      });
    } catch (error: any) {
      console.error('Error creating order:', error);
      return res.status(500).json({
        success: false,
        message: 'Internal server error processing pre-order.'
      });
    }
  });

  // PATCH /api/orders/:orderId/status - Update order status (Barista workflow)
  app.patch('/api/orders/:orderId/status', (req, res) => {
    const { orderId } = req.params;
    const { status } = req.body;

    const order = orders.find((o) => o.orderId.toLowerCase() === orderId.toLowerCase());
    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    if (!['received', 'preparing', 'ready_for_pickup', 'completed'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status value' });
    }

    order.status = status as any;
    return res.json({ success: true, data: order });
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Café DoiTung server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
