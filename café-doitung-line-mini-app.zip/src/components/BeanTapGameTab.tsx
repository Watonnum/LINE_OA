import React, { useState } from 'react';
import { Flame, RefreshCw, Sparkles, Coffee, Gift, Trophy, Check } from 'lucide-react';

interface BeanTapGameTabProps {
  userBeans: number;
  onAddBeans: (amount: number) => void;
}

interface FloatingText {
  id: number;
  amount: number;
  x: number;
  y: number;
}

export const BeanTapGameTab: React.FC<BeanTapGameTabProps> = ({
  userBeans,
  onAddBeans
}) => {
  const [sessionScore, setSessionScore] = useState(120);
  const [roastLevel, setRoastLevel] = useState(3); // 1-5 level
  const [energy, setEnergy] = useState(998);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [isTapped, setIsTapped] = useState(false);
  const [redeemedVoucher, setRedeemedVoucher] = useState<string | null>(null);

  const handleTap = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    if (energy <= 0) return;

    // Calculate gain amount
    const isCritical = Math.random() < 0.2;
    const gain = isCritical ? 110 : 10;

    // Get position relative to click
    const rect = e.currentTarget.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    const x = clientX - rect.left;
    const y = clientY - rect.top;

    const newFloat: FloatingText = {
      id: Date.now() + Math.random(),
      amount: gain,
      x: x + (Math.random() * 20 - 10),
      y: y + (Math.random() * 20 - 10)
    };

    setFloatingTexts((prev) => [...prev.slice(-10), newFloat]);
    setSessionScore((prev) => prev + gain);
    onAddBeans(gain);
    setEnergy((prev) => Math.max(0, prev - 1));

    setIsTapped(true);
    setTimeout(() => setIsTapped(false), 80);

    // Update roast meter randomly
    if (Math.random() < 0.3) {
      setRoastLevel((prev) => (prev % 5) + 1);
    }
  };

  const handleRedeemVoucher = (cost: number, code: string) => {
    if (userBeans >= cost) {
      onAddBeans(-cost);
      setRedeemedVoucher(code);
    } else {
      alert(`คุณต้องใช้ ${cost} Beans เพื่อแลกส่วนลดนี้ (ปัจจุบันมี ${userBeans} Beans)`);
    }
  };

  return (
    <div className="relative min-h-[500px] flex flex-col justify-between p-4 pb-24 text-white overflow-hidden">
      {/* Top Status Bar matching Screenshot 3 */}
      <div className="flex items-center justify-between z-10">
        <div className="bg-[#132218] border border-[#1E3A24] px-3.5 py-1.5 rounded-full flex items-center space-x-2 shadow-md">
          <span className="text-amber-400 font-black text-xs">Beans :</span>
          <span className="text-white font-extrabold text-sm">{userBeans.toLocaleString()}</span>
        </div>

        {/* Roast Level Indicator matching screenshot right bar */}
        <div className="flex items-center space-x-2 bg-[#132218] border border-[#1E3A24] px-3 py-1.5 rounded-full">
          <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">Roast Level</span>
          <div className="flex items-center space-x-1">
            {[1, 2, 3, 4, 5].map((lvl) => (
              <span
                key={lvl}
                className={`w-2 h-2 rounded-full transition-all ${
                  lvl <= roastLevel
                    ? lvl > 3
                      ? 'bg-amber-400 shadow-[0_0_8px_#F59E0B]'
                      : 'bg-[#06C755] shadow-[0_0_8px_#06C755]'
                    : 'bg-stone-700'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Main Coffee Bean Tap Target Area */}
      <div className="relative my-auto py-8 flex flex-col items-center justify-center select-none z-10">
        {/* Floating Numbers Layer */}
        <div className="absolute inset-0 pointer-events-none z-30">
          {floatingTexts.map((ft) => (
            <div
              key={ft.id}
              style={{ left: `${ft.x}px`, top: `${ft.y}px` }}
              className="absolute animate-float-up text-amber-400 font-black text-2xl drop-shadow-[0_2px_10px_rgba(245,158,11,0.8)]"
            >
              +{ft.amount}
            </div>
          ))}
        </div>

        {/* Center Mascot Coffee Bean Container matching Screenshot 3 Frog Tap Game */}
        <div
          onClick={handleTap}
          onTouchStart={handleTap}
          className={`relative cursor-pointer transition-transform duration-75 active:scale-95 flex flex-col items-center justify-center p-6 rounded-full ${
            isTapped ? 'scale-90' : 'scale-100'
          }`}
        >
          {/* Glowing background aura */}
          <div className="absolute w-64 h-64 rounded-full bg-emerald-500/15 filter blur-2xl animate-pulse pointer-events-none" />

          {/* Coffee Cup / Bean Image Mascot */}
          <div className="relative w-48 h-48 sm:w-56 sm:h-56 rounded-full bg-[#132218] border-4 border-[#06C755]/50 flex items-center justify-center shadow-2xl green-glow overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=600&q=80"
              alt="DoiTung Coffee Bean Tap"
              className="w-full h-full object-cover opacity-90 hover:opacity-100 transition duration-300"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0A110C] via-transparent to-transparent opacity-60" />
            
            <div className="absolute bottom-4 bg-[#0A110C]/90 px-3 py-1 rounded-full border border-amber-400/40 text-[11px] text-amber-300 font-bold flex items-center space-x-1 shadow-lg">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>TAP TO ROAST</span>
            </div>
          </div>
        </div>

        {/* Energy Bar */}
        <div className="w-64 mt-4 space-y-1 text-center">
          <div className="flex items-center justify-between text-[11px] text-stone-400 font-semibold px-1">
            <span>⚡ Brew Energy</span>
            <span className="text-emerald-400 font-bold">{energy}/1000</span>
          </div>
          <div className="w-full h-2.5 rounded-full bg-stone-800 border border-stone-700 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-emerald-500 to-[#06C755] transition-all duration-300 shadow-[0_0_10px_#06C755]"
              style={{ width: `${(energy / 1000) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* Discount Coupon Redemption Section */}
      <div className="space-y-2 mb-3 bg-[#132218] border border-[#1E3A24] p-3 rounded-2xl">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-amber-400 flex items-center space-x-1">
            <Gift className="w-4 h-4" />
            <span>Redeem Coffee Vouchers</span>
          </span>
          <span className="text-[10px] text-stone-400">Use in Pre-Order Menu</span>
        </div>

        {redeemedVoucher ? (
          <div className="p-2.5 bg-emerald-950 border border-emerald-500/50 rounded-xl text-xs text-emerald-200 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Check className="w-4 h-4 text-[#06C755]" />
              <span>ใช้สิทธิ์คูปองส่วนลด <strong>{redeemedVoucher}</strong> ในตะกร้าแล้ว!</span>
            </div>
            <button
              onClick={() => setRedeemedVoucher(null)}
              className="text-[10px] text-stone-400 hover:text-white underline"
            >
              Reset
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => handleRedeemVoucher(500, 'DISCOUNT20THB')}
              className="p-2 bg-[#1A2F21] hover:bg-emerald-900/60 border border-[#23422C] rounded-xl text-left transition"
            >
              <div className="text-[10px] text-stone-400">500 Beans</div>
              <div className="text-xs font-bold text-amber-300">ส่วนลด ฿20 บาท</div>
            </button>

            <button
              onClick={() => handleRedeemVoucher(1200, 'DISCOUNT50THB')}
              className="p-2 bg-[#1A2F21] hover:bg-emerald-900/60 border border-[#23422C] rounded-xl text-left transition"
            >
              <div className="text-[10px] text-stone-400">1,200 Beans</div>
              <div className="text-xs font-bold text-emerald-300">ส่วนลด ฿50 บาท</div>
            </button>
          </div>
        )}
      </div>

      {/* Bottom Game Dock Control matching Screenshot 3 */}
      <div className="flex items-center space-x-2 z-10">
        <div className="flex-1 bg-[#132218] border border-[#1E3A24] py-3 px-4 rounded-2xl text-xs text-stone-300 font-bold flex items-center justify-between">
          <span>Score :</span>
          <span className="text-base text-amber-400 font-black">{sessionScore}</span>
        </div>

        <button
          onClick={() => {
            setSessionScore(0);
            setEnergy(1000);
          }}
          className="py-3 px-4 bg-[#06C755] hover:bg-[#05b34c] active:bg-[#049a41] text-stone-950 font-extrabold rounded-2xl shadow-lg transition active:scale-95 flex items-center space-x-1.5 text-xs"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Restart Game</span>
        </button>
      </div>
    </div>
  );
};
