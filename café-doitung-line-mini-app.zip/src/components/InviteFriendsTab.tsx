import React, { useState } from 'react';
import { Users, Share2, Copy, Check, Sparkles, Award, Gift, ChevronRight, Coins } from 'lucide-react';
import { InvitedFriend, LineUserProfile } from '../types';

interface InviteFriendsTabProps {
  isSharePickerAvailable: boolean;
  onInviteFriends: () => void;
  userProfile: LineUserProfile | null;
  userBeans: number;
}

export const InviteFriendsTab: React.FC<InviteFriendsTabProps> = ({
  isSharePickerAvailable,
  onInviteFriends,
  userProfile,
  userBeans
}) => {
  const [copied, setCopied] = useState(false);

  // Mock list of invited friends
  const friendsList: InvitedFriend[] = [
    {
      id: 'f1',
      name: 'Niran (นิรันดร์)',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&q=80',
      joinedDate: '2 hours ago',
      bonusBeans: 100,
      status: 'Active'
    },
    {
      id: 'f2',
      name: 'Ploy (พลอย)',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&q=80',
      joinedDate: 'Yesterday',
      bonusBeans: 100,
      status: 'Joined'
    },
    {
      id: 'f3',
      name: 'Korn (กร)',
      avatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=120&q=80',
      joinedDate: '3 days ago',
      bonusBeans: 300,
      status: 'Active'
    }
  ];

  const handleCopyLink = () => {
    const liffId = (import.meta as any).env?.VITE_LIFF_ID || '1657000000-xxxxxx';
    const link = `https://liff.line.me/${liffId}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4 pb-20 px-4 pt-2">
      {/* Hero Header matching screenshot Screen 2 */}
      <div className="text-center pt-2 pb-1 space-y-2">
        {/* 3 Avatars Graphics */}
        <div className="flex items-center justify-center -space-x-3 mb-1">
          <div className="w-12 h-12 rounded-full border-2 border-[#06C755] bg-amber-100 overflow-hidden shadow-lg transform -rotate-6">
            <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80" alt="Avatar 1" className="w-full h-full object-cover" />
          </div>
          <div className="w-14 h-14 rounded-full border-2 border-amber-400 bg-emerald-800 overflow-hidden shadow-xl z-10 transform scale-105">
            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80" alt="Avatar 2" className="w-full h-full object-cover" />
          </div>
          <div className="w-12 h-12 rounded-full border-2 border-[#06C755] bg-stone-700 overflow-hidden shadow-lg transform rotate-6">
            <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80" alt="Avatar 3" className="w-full h-full object-cover" />
          </div>
        </div>

        <h2 className="text-2xl font-black tracking-wider uppercase text-white font-serif">
          INVITE <span className="text-amber-400">FRIENDS</span>
        </h2>
        <p className="text-xs text-stone-300 font-medium max-w-xs mx-auto">
          You and your friend will receive +100 DoiTung Bean Points for coffee discounts!
        </p>

        {/* Earned Summary Card */}
        <div className="pt-2">
          <div className="inline-flex items-center justify-center space-x-4 bg-[#132218] border border-[#1E3A24] px-5 py-2 rounded-2xl shadow-inner">
            <div className="flex items-center space-x-1.5">
              <span className="text-lg">🪙</span>
              <div className="text-left">
                <span className="text-[10px] text-stone-400 block -mb-0.5">Earned Beans</span>
                <span className="text-sm font-black text-amber-400">{userBeans.toLocaleString()}</span>
              </div>
            </div>
            <div className="w-px h-6 bg-stone-800" />
            <div className="flex items-center space-x-1.5">
              <span className="text-lg">💎</span>
              <div className="text-left">
                <span className="text-[10px] text-stone-400 block -mb-0.5">VIP Stamps</span>
                <span className="text-sm font-black text-emerald-400">20</span>
              </div>
            </div>
          </div>
        </div>

        {/* Invite Main Actions */}
        <div className="pt-3 flex items-center justify-center space-x-2 max-w-xs mx-auto">
          <button
            onClick={onInviteFriends}
            className="flex-1 py-3 px-4 rounded-2xl bg-[#06C755] hover:bg-[#05b34c] active:bg-[#049a41] text-stone-950 text-sm font-extrabold shadow-lg shadow-emerald-900/40 transition active:scale-98 flex items-center justify-center space-x-2"
          >
            <Users className="w-4 h-4" />
            <span>Invite a Friend</span>
          </button>
          <button
            onClick={handleCopyLink}
            title="Copy Invite Link"
            className="p-3 rounded-2xl bg-[#132218] hover:bg-[#1A2D20] text-emerald-400 border border-[#1E3A24] transition active:scale-95"
          >
            {copied ? <Check className="w-5 h-5 text-amber-400" /> : <Copy className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mission Option Cards matching Screenshot 2 */}
      <div className="space-y-2.5 pt-2">
        <div
          onClick={onInviteFriends}
          className="bg-[#132218] border border-[#1E3A24] hover:border-[#06C755]/50 rounded-2xl p-3.5 flex items-center justify-between cursor-pointer transition shadow-md active:scale-98"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Invite a friend</h4>
              <p className="text-xs text-amber-400 font-extrabold">+100 DoiTung Beans</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-stone-500" />
        </div>

        <div
          onClick={onInviteFriends}
          className="bg-[#132218] border border-[#1E3A24] hover:border-[#06C755]/50 rounded-2xl p-3.5 flex items-center justify-between cursor-pointer transition shadow-md active:scale-98"
        >
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-[#06C755]">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white">Invite via LINE Official Account</h4>
              <p className="text-xs text-emerald-400 font-extrabold">+300 DoiTung Beans (VIP)</p>
            </div>
          </div>
          <ChevronRight className="w-5 h-5 text-stone-500" />
        </div>
      </div>

      {/* List of your friends */}
      <div className="pt-3 space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-stone-200 tracking-wide">
            List of your friends ({friendsList.length})
          </h3>
          <span className="text-xs text-[#06C755] font-semibold">Total +500 Beans</span>
        </div>

        <div className="space-y-2">
          {friendsList.map((f) => (
            <div
              key={f.id}
              className="bg-[#132218] border border-[#1E3A24] rounded-2xl p-3 flex items-center justify-between"
            >
              <div className="flex items-center space-x-3">
                <img
                  src={f.avatar}
                  alt={f.name}
                  className="w-10 h-10 rounded-full object-cover border border-emerald-700/50"
                />
                <div>
                  <h5 className="text-xs font-bold text-white">{f.name}</h5>
                  <span className="text-[10px] text-stone-400">{f.joinedDate}</span>
                </div>
              </div>
              <div className="text-right">
                <span className="text-xs font-extrabold text-amber-400 block">
                  +{f.bonusBeans} Beans
                </span>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-900/60 text-emerald-300 border border-emerald-700/40">
                  {f.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
